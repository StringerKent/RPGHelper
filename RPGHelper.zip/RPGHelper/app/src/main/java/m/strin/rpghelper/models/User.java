package m.strin.rpghelper.models;

public class User {
}
