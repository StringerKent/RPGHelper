package m.strin.rpghelper.models;

public class PlayerCharacter {
    private String name;
    private String characterClass;
    private String characterRace;
    private String characterGender;
    private String characterAlighnment;
    private String characterEyes;
    private String characterHair;
    private String characterHeight;
    private String characterWeight;
    private String characterDeity;
    private String characterSize;

    private int level;
    private int nextLevelXP;
    private int currentXP;

    private int strength;
    private int dexterity;
    private int constitution;
    private int intelligence;
    private int wisdom;
    private int charisma;

    private int armorClass;
    private int rolledHealth;
    private int maxHealth;
    private int currentHealth;

    private int strengthSavingThrow;
    private int dexteritySavingThrow;
    private int constitutionSavingThrow;
    private int intelligenceSavingThrow;
    private int wisdomSavingThrow;
    private int charismaSavingThrow;

    private int Acrobatics;
    private int AnimalHandling;
    private int Arcana;
    private int Athletics;
    private int Deception;
    private int History;
    private int Insight;
    private int Intimidation;
    private int Investigation;
    private int Medicine;
    private int Nature;
    private int Perception;
    private int Performance;
    private int Persuasion;
    private int Religion;
    private int Sleight;
    private int Stealth;
    private int Survival;

    private int gold;
    private int silver;
    private int copper;
    private int platinum;

    private int lightEncumbrance;
    private int heavyEncumbrance;
    private int maxEncumbrance;

    public PlayerCharacter() {
    }

    public int getStatBonus(int stat){
        return (stat - 10)/2;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getCharacterClass() {
        return characterClass;
    }

    public void setCharacterClass(String characterClass) {
        this.characterClass = characterClass;
    }

    public String getCharacterRace() {
        return characterRace;
    }

    public void setCharacterRace(String characterRace) {
        this.characterRace = characterRace;
    }

    public String getCharacterGender() {
        return characterGender;
    }

    public void setCharacterGender(String characterGender) {
        this.characterGender = characterGender;
    }

    public String getCharacterAlighnment() {
        return characterAlighnment;
    }

    public void setCharacterAlighnment(String characterAlighnment) {
        this.characterAlighnment = characterAlighnment;
    }

    public String getCharacterEyes() {
        return characterEyes;
    }

    public void setCharacterEyes(String characterEyes) {
        this.characterEyes = characterEyes;
    }

    public String getCharacterHair() {
        return characterHair;
    }

    public void setCharacterHair(String characterHair) {
        this.characterHair = characterHair;
    }

    public String getCharacterHeight() {
        return characterHeight;
    }

    public void setCharacterHeight(String characterHeight) {
        this.characterHeight = characterHeight;
    }

    public String getCharacterWeight() {
        return characterWeight;
    }

    public void setCharacterWeight(String characterWeight) {
        this.characterWeight = characterWeight;
    }

    public String getCharacterDeity() {
        return characterDeity;
    }

    public void setCharacterDeity(String characterDeity) {
        this.characterDeity = characterDeity;
    }

    public String getCharacterSize() {
        return characterSize;
    }

    public void setCharacterSize(String characterSize) {
        this.characterSize = characterSize;
    }

    public int getLevel() {
        return level;
    }

    public void setLevel(int level) {
        this.level = level;
    }

    public int getNextLevelXP() {
        return nextLevelXP;
    }

    public void setNextLevelXP(int nextLevelXP) {
        this.nextLevelXP = nextLevelXP;
    }

    public int getCurrentXP() {
        return currentXP;
    }

    public void setCurrentXP(int currentXP) {
        this.currentXP = currentXP;
    }

    public int getStrength() {
        return strength;
    }

    public void setStrength(int strength) {
        this.strength = strength;
    }

    public int getDexterity() {
        return dexterity;
    }

    public void setDexterity(int dexterity) {
        this.dexterity = dexterity;
    }

    public int getConstitution() {
        return constitution;
    }

    public void setConstitution(int constitution) {
        this.constitution = constitution;
    }

    public int getIntelligence() {
        return intelligence;
    }

    public void setIntelligence(int intelligence) {
        this.intelligence = intelligence;
    }

    public int getWisdom() {
        return wisdom;
    }

    public void setWisdom(int wisdom) {
        this.wisdom = wisdom;
    }

    public int getCharisma() {
        return charisma;
    }

    public void setCharisma(int charisma) {
        this.charisma = charisma;
    }

    public int getArmorClass() {
        return armorClass;
    }

    public void setArmorClass(int armorClass) {
        this.armorClass = armorClass;
    }

    public int getRolledHealth() {
        return rolledHealth;
    }

    public void setRolledHealth(int rolledHealth) {
        this.rolledHealth = rolledHealth;
    }

    public int getMaxHealth() {
        return maxHealth;
    }

    public void setMaxHealth(int maxHealth) {
        this.maxHealth = maxHealth;
    }

    public int getCurrentHealth() {
        return currentHealth;
    }

    public void setCurrentHealth(int currentHealth) {
        this.currentHealth = currentHealth;
    }

    public int getStrengthSavingThrow() {
        return strengthSavingThrow;
    }

    public void setStrengthSavingThrow(int strengthSavingThrow) {
        this.strengthSavingThrow = strengthSavingThrow;
    }

    public int getDexteritySavingThrow() {
        return dexteritySavingThrow;
    }

    public void setDexteritySavingThrow(int dexteritySavingThrow) {
        this.dexteritySavingThrow = dexteritySavingThrow;
    }

    public int getConstitutionSavingThrow() {
        return constitutionSavingThrow;
    }

    public void setConstitutionSavingThrow(int constitutionSavingThrow) {
        this.constitutionSavingThrow = constitutionSavingThrow;
    }

    public int getIntelligenceSavingThrow() {
        return intelligenceSavingThrow;
    }

    public void setIntelligenceSavingThrow(int intelligenceSavingThrow) {
        this.intelligenceSavingThrow = intelligenceSavingThrow;
    }

    public int getWisdomSavingThrow() {
        return wisdomSavingThrow;
    }

    public void setWisdomSavingThrow(int wisdomSavingThrow) {
        this.wisdomSavingThrow = wisdomSavingThrow;
    }

    public int getCharismaSavingThrow() {
        return charismaSavingThrow;
    }

    public void setCharismaSavingThrow(int charismaSavingThrow) {
        this.charismaSavingThrow = charismaSavingThrow;
    }

    public int getAcrobatics() {
        return Acrobatics;
    }

    public void setAcrobatics(int acrobatics) {
        Acrobatics = acrobatics;
    }

    public int getAnimalHandling() {
        return AnimalHandling;
    }

    public void setAnimalHandling(int animalHandling) {
        AnimalHandling = animalHandling;
    }

    public int getArcana() {
        return Arcana;
    }

    public void setArcana(int arcana) {
        Arcana = arcana;
    }

    public int getAthletics() {
        return Athletics;
    }

    public void setAthletics(int athletics) {
        Athletics = athletics;
    }

    public int getDeception() {
        return Deception;
    }

    public void setDeception(int deception) {
        Deception = deception;
    }

    public int getHistory() {
        return History;
    }

    public void setHistory(int history) {
        History = history;
    }

    public int getInsight() {
        return Insight;
    }

    public void setInsight(int insight) {
        Insight = insight;
    }

    public int getIntimidation() {
        return Intimidation;
    }

    public void setIntimidation(int intimidation) {
        Intimidation = intimidation;
    }

    public int getInvestigation() {
        return Investigation;
    }

    public void setInvestigation(int investigation) {
        Investigation = investigation;
    }

    public int getMedicine() {
        return Medicine;
    }

    public void setMedicine(int medicine) {
        Medicine = medicine;
    }

    public int getNature() {
        return Nature;
    }

    public void setNature(int nature) {
        Nature = nature;
    }

    public int getPerception() {
        return Perception;
    }

    public void setPerception(int perception) {
        Perception = perception;
    }

    public int getPerformance() {
        return Performance;
    }

    public void setPerformance(int performance) {
        Performance = performance;
    }

    public int getPersuasion() {
        return Persuasion;
    }

    public void setPersuasion(int persuasion) {
        Persuasion = persuasion;
    }

    public int getReligion() {
        return Religion;
    }

    public void setReligion(int religion) {
        Religion = religion;
    }

    public int getSleight() {
        return Sleight;
    }

    public void setSleight(int sleight) {
        Sleight = sleight;
    }

    public int getStealth() {
        return Stealth;
    }

    public void setStealth(int stealth) {
        Stealth = stealth;
    }

    public int getSurvival() {
        return Survival;
    }

    public void setSurvival(int survival) {
        Survival = survival;
    }

    public int getGold() {
        return gold;
    }

    public void setGold(int gold) {
        this.gold = gold;
    }

    public int getSilver() {
        return silver;
    }

    public void setSilver(int silver) {
        this.silver = silver;
    }

    public int getCopper() {
        return copper;
    }

    public void setCopper(int copper) {
        this.copper = copper;
    }

    public int getPlatinum() {
        return platinum;
    }

    public void setPlatinum(int platinum) {
        this.platinum = platinum;
    }

    public int getLightEncumbrance() {
        return lightEncumbrance;
    }

    public void setLightEncumbrance(int lightEncumbrance) {
        this.lightEncumbrance = lightEncumbrance;
    }

    public int getHeavyEncumbrance() {
        return heavyEncumbrance;
    }

    public void setHeavyEncumbrance(int heavyEncumbrance) {
        this.heavyEncumbrance = heavyEncumbrance;
    }

    public int getMaxEncumbrance() {
        return maxEncumbrance;
    }

    public void setMaxEncumbrance(int maxEncumbrance) {
        this.maxEncumbrance = maxEncumbrance;
    }
}
